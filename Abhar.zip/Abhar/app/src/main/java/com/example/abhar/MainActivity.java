package com.example.abhar;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private EditText editTextMessage;
    private Button buttonSend;
    private LinearLayout messageContainer;

    private final String serverIP = "192.168.1.5";
    private final int port = 5555;

    private Socket socket;
    private PrintWriter outputStream;
    private BufferedReader inputStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextMessage = findViewById(R.id.editTextMessage);
        buttonSend = findViewById(R.id.buttonSend);
        messageContainer = findViewById(R.id.messageContainer);

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });

        // Connect to the server
        new ConnectToServerTask().execute();
    }

    private void sendMessage() {
        final String message = editTextMessage.getText().toString().trim();
        if (!message.isEmpty()) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    if (outputStream != null) {
                        outputStream.println("\nClient: "+message);
                    }
                }
            }).start();
        }
    }

    private void addMessageToUI(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TextView textView = new TextView(MainActivity.this);
                textView.setText(message);
                messageContainer.addView(textView);
            }
        });
    }

    private class ConnectToServerTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                socket = new Socket(serverIP, port);
                outputStream = new PrintWriter(socket.getOutputStream(), true);
                inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // Listen for incoming messages from the server
                String receivedMessage;
                while ((receivedMessage = inputStream.readLine()) != null) {
                    addMessageToUI("Server: " + receivedMessage+"\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
                showToast("Error connecting to server: " + e.getMessage());
            }
            return null;
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (inputStream != null) inputStream.close();
            if (outputStream != null) outputStream.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
